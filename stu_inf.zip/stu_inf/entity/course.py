class course:
    cid = 0
    cname = ''
    def __init__(self,cid,cname):
        print("course initiate")
        self.cname = cname
        self.cid = cid
    def setCid(self,cid):
         self.cid=cid
    def getCid(self):
        return self.cid
    def setCname(self,cname):
         self.cname=cname
    def getCname(self):
        return self.cname