from entity import course
class student:                              #student类
  id = 0                                    #学生基本信息
  name = ""
  sex = ""
  address = ""
  courseList = []                #课程列表
  classList = []               #班级列表
  indexC = 0              #课程游标
  indexCl = 0           #班级游标
  def __init__(self,id,name,sex,address,course,cla):
      print("student initiate")
      self.id = id
      self.name = name
      self.sex = sex
      self.address = address
      self.setSli(course)
      self.setCll(cla)
  def setId(self,id):
      self.id=id
  def getId(self):
      return self.id
  def setName(self,name):
      self.name=name
  def getName(self):
      return self.name
  def setSex(self,sex):
      self.sex=sex
  def getSex(self):
      return self.sex
  def setAddr(self,address):
      self.address=address
  def getAddr(self):
      return self.address
  def setSli(self,course):
      self.courseList.insert(self.indexC,course)
      self.indexC+=1
      #print("课程添加测试")
  def getSli(self):
      return self.courseList
  def setCll(self,clas):
      self.classList.insert(self.indexCl,clas)
  def getCll(self):
      return self.classList
'''
stu = student()
stu.setId(input("please input your ID:"))
stu.setName(input("please input your name:"))
stu.setSex(input("please input your sex:"))
stu.setAddr(input("please input your address:"))
print("id为：",stu.getId(),"姓名为：",stu.getName(),"性别：",stu.getSex(),"住址：",stu.getAddr())
stu.setSli(course.course(1,'英语'))
stu.setSli(course.course(2,'数学'))
print("list测试：",stu.getSli().__getitem__(1).cname)
for cc in stu.getSli():
    print("课程id：",cc.getCid(),"课程名称：",cc.getCname())
'''




