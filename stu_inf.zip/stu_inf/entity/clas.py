class clas:
    clid = 0
    clname = ''
    def __init__(self,clid,clname):
        print("class initiate")
        self.clid = clid
        self.clname = clname

    def setClid(self,clid):
        self.clid = clid
    def getClid(self):
        return self.clid
    def setClname(self,clname):
        self.clname = clname
    def getCliname(self):
        return self.clname