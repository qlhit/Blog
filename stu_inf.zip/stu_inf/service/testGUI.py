class fibo:
    counter, a ,b = 0, 0, 1
    def fiboo(self,max):
        while self.counter < max:
            yield  self.b
            self.a, self.b = self.b, self.a + self.b
            self.counter+=1
F = fibo()
for var in F.fiboo(10):
    print(var)