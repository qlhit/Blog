from entity import student
from entity import course
from entity import clas
class test:
    indexS = 0

    # 学生集合
    stuList = []

    #option
    delStu = ["y","n"]

    # 初始化
    def __init__(self):
        print("test initiate")
        # 弹出选项
    def testOption(self):
        print("Please select your operation following:\n"
              +"\t 1.user create\n"
              +"\t 2.user delete\n"
              +"\t 3.user search")
        temp = int(input("Please input your number pleased:"))
        # 创建stu
        if temp == 1:
            print("the choice you selected is ONE")
            self.testAdd()
            print("User Add Successful!")

        # 删除stu
        elif temp == 2:
            print("the choice you selected is TWO")
            dname = input("please input the name you want to delete:")
            for tmpVar in self.stuList:
                if str(tmpVar.getName()).__eq__(dname):
                    self.testShow(tmpVar)
                    varRE = str(input("Are you sure to delete this people?:"))
                    while (self.delStu.__contains__(varRE.lower())):
                        if varRE.lower().__eq__("y"):
                            try:
                                self.stuList.remove(tmpVar)
                                print("User Delete Successful!")
                                continue
                            except ValueError:
                                print("Appearanced ValueError")
                                break
                        else:
                            print("User Delete failure!")
                            break
                    else:
                        print("please input correct key(y/n)")

        # 查找stu
        else:
            print("the choice you selected is THREE")
            sname = str(input("please input your search key(default name):"))
            for stu in self.stuList:
                if str(stu.getName()).__eq__(sname):
                    self.testShow(stu)
                    print("the information you acquired is:\n")
                    self.testShow(stu)
            print("User Search Successful!")

    # stu添加功能实现
    def testAdd(self):
        stu = student.student(input("please input your ID:"),input("please input your name:"),
                              input("please input your sex:"),input("please input your address:"),
                              course.course(input("please input your courseID:"),input("please input your courseName:")),
                              clas.clas(input("please input your classID:"),input("please input your className:")))
        self.stuList.insert(self.indexS,stu)
        self.indexS+=1
        self.testShow(stu)

    # 结果显示
    def testShow(self, stu):
        print("The personal information as folowing:\nstudent ID is:", stu.getId() + '\n', "student name is:",
              stu.getName() + '\n',
              "student sex is:", stu.getSex() + '\n', "student address is:", stu.getAddr() + '\n',
              "course choosed are:", stu.getSli().__getitem__(0).getCname() + '\n',
              "class studied is:", stu.getCll().__getitem__(0).getCliname())

test = test()
while 1:
    test.testOption()

