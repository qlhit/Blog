#!/bin/bash -x
echo "Removing CVS directories under current directory if any exist  ..."
/bin/find . -type d -name "CVS" -exec /bin/rm -rf  {} \;


